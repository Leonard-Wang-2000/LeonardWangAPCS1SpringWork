//APCS1 Leonard Wang 1stperiod
package textExcel;
public class FormulaCell extends RealCell{
	private String value = "";
	public FormulaCell(String input){
		value = input;
		//stores string in parent class
		setRealCell(value);
	}
	public double getDoubleValue(){
		//return anything u want
		return 100.0;
	}
	public String abbreviatedCellText(){
		return value;
	}
	public String fullCellText(){
		return value;
	}
}
